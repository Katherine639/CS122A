// The following is sample code for how to create a main.c that works with scheduler.h
// This program will cause D0 to blink on and off every 1500ms. D4D5D6 will rotate every 500ms.
// This code will work with the ATMega1284 or ATMega32

#include <avr/io.h>
#include <scheduler.h>
#include "usart_ATmega1284.h"

volatile unsigned char PORTA_TEMP = 0x00;
unsigned char USART_flag = 0xFF;
//transmitter + receiver code
//receive on USART0
//send on USART1

void buttonCheck(void) {
	if (~PINB & 0x01) {
		USART_flag = ~USART_flag;
	}
	PORTC = USART_flag;
	return;
}

enum BL_States { SM1_TX_On, SM1_TX_Off, SM1_RX };
int TickFct_BlinkLED(int state) {
	switch(state) { // Transitions
		case -1: // Initial transition
		initUSART(0); //receiver
		initUSART(1); //transmitter
		state = SM1_TX_On;
		break;
		case SM1_TX_On:
		buttonCheck();
		if (!USART_flag) {
			state = SM1_RX;
			break;
		}
		
		if (USART_HasTransmitted(1)) {
			state = SM1_TX_Off;
		} else {
			state = SM1_TX_On;
		}
		break;
		case SM1_TX_Off:
		buttonCheck();
		if (!USART_flag) {
			state = SM1_RX;
			break;
		}
		
		if (USART_HasTransmitted(1)) {
			state = SM1_TX_On;
		} else {
			state = SM1_TX_Off;
		}
		break;
		case SM1_RX:
		buttonCheck();
		if(USART_flag) {
			state = SM1_TX_On;
		} else {
			state = SM1_RX;
		}
		break;
		default:
		state = SM1_TX_On;
	}

	switch(state) { // State actions
		case SM1_TX_On:
		PORTA_TEMP |= 0x01;
		PORTA = PORTA_TEMP;
		if (USART_IsSendReady(1) ) {
			USART_Send(PORTA_TEMP, 1);
		}
		break;
		case SM1_TX_Off:
		PORTA_TEMP &= 0xFE;
		PORTA = PORTA_TEMP;
		if (USART_IsSendReady(1) ) {
			USART_Send(PORTA_TEMP, 1);
		}
		break;
		case SM1_RX:
		if ( USART_HasReceived(0) ) {
			PORTA_TEMP = USART_Receive(0);
			PORTA = PORTA_TEMP;
			USART_Flush(0);
		}
		default:
		break;
	}
	
	//PORTA = PORTA_TEMP;
	return state;
}

enum TL_States { SM2_Cyc1, SM2_Cyc2, SM2_Cyc3 };
int TickFct_ThreeLEDs(int state) {
	switch(state) { // Transitions
		case -1: // Initial transition
		state = SM2_Cyc1;
		break;
		case SM2_Cyc1:
		state = SM2_Cyc2;
		break;
		case SM2_Cyc2:
		state = SM2_Cyc3;
		break;
		case SM2_Cyc3:
		state = SM2_Cyc1;
		break;
		default:
		state = -1;
	}

	switch(state) { // State actions
		case SM2_Cyc1:
		PORTA_TEMP = (PORTA_TEMP & 0x0F) | 0x10;
		break;
		case SM2_Cyc2:
		PORTA_TEMP = (PORTA_TEMP & 0x0F) | 0x20;
		break;
		case SM2_Cyc3:
		PORTA_TEMP = (PORTA_TEMP & 0x0F) | 0x40;
		break;
		default:
		break;
	}
	
	PORTA = PORTA_TEMP;
	return state;
}

int main(void) {
	
	// initialize ports
	DDRA = 0xFF; PORTA = 0x00;
	DDRB = 0x00; PORTB = 0xFF;
	DDRC = 0xFF; PORTC = 0x00;
	
	tasksNum = 1; // declare number of tasks
	task tsks[1]; // initialize the task array
	tasks = tsks; // set the task array
	
	// define tasks
	unsigned char i=0; // task counter
	tasks[i].state = -1;
	tasks[i].period = 100;
	tasks[i].elapsedTime = tasks[i].period;
	tasks[i].TickFct = &TickFct_BlinkLED;
	++i;
	
	/*
	tasks[i].state = -1;
	tasks[i].period = 0;
	tasks[i].elapsedTime = tasks[i].period;
	tasks[i].TickFct = &TickFct_ThreeLEDs;
	*/
	
	TimerSet(100); // value set should be GCD of all tasks
	TimerOn();

	while(1) {} // task scheduler will be called by the hardware interrupt
	
}
